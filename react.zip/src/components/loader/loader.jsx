const Loader = ()=>{
    return(
        <div className="loaderContent">
                <div className="loaderIcon"></div>
            </div>
     )
}
export default Loader