import React, { useState, useContext } from 'react';

const Wtres = ()=>{
    return (<>
        <h1>Hola desde web3component</h1>
    </>)
}

export default Wtres